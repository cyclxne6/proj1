import pygame

class Button:
    def __init__(self, x, y, image, scale=1.0):
        self.original_image = image
        width = image.get_width()
        height = image.get_height()

        self.image = pygame.transform.scale(image, (int(width * scale), int(height * scale)))
        self.rect = self.image.get_rect(topleft=(x, y))

        self.active = True      # controls whether it's visible/clickable
        self.clicked = False    # internal debouncing flag

    def draw(self, surface):
        """Draws the button if active."""
        if self.active:
            surface.blit(self.image, self.rect.topleft)

    def is_clicked(self):
        """Returns True if the button was just clicked."""
        if not self.active:
            return False

        pos = pygame.mouse.get_pos()
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and not self.clicked:
                self.clicked = True
                print(f"Button clicked at {self.rect.topleft}")  # Debug
                return True  # Click triggered
        if pygame.mouse.get_pressed()[0] == 0:
            self.clicked = False
        return False

    def move(self, x, y):
        """Moves the button to a new position."""
        self.rect.topleft = (x, y)

