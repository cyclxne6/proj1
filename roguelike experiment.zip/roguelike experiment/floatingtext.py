import pygame

class FloatingText(pygame.sprite.Sprite):
    def __init__(self, x, y, text, font, color, duration):
        super().__init__()
        self.x = float(x)
        self.y = float(y)
        self.font = font
        self.text = text
        self.color = color
        self.image = self.font.render(text, True, color)
        self.rect = self.image.get_rect(center=(x, y))
        self.lifetime = duration    # seconds to live
        self.timer = 0                   # elapsed time
        self.speed = -30              # pixels per second (negative = up)

    def update(self, delta_time):
        # move up
        dy = self.speed * delta_time
        self.y += dy
        self.rect.center = (self.x, int(self.y))
        print(f"FloatingText Y: {self.rect.y}")  # debug prin

        self.timer += delta_time
        if self.timer >= self.lifetime:
            self.kill()

    def draw(self, surface):
        self.image = self.font.render(self.text, True, self.color)
        surface.blit(self.image, self.rect)
