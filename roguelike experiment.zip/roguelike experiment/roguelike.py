#TODO

#add resolutions in options menu

#add enemies (melee (basic, dasher), ranged(bow, blaster), support(healer, stat buffs))
#add attacks
#add weapons (stick, sword(s), crossbow, gun(single-shot, auto), utility (passive stat increase))

#add kill functions (on kill effects, cash on kill, etc)

#add shop (3 items, random items and 2 utility items (new one spawns when anything is bought))
#add secret fight
#/TODO

#NOTE
#reversed vectors (+X = left, +y = down) (i hate this rule)
#.set_colorkey to ignore a colour i.e. greenscreening = image.set_colorkey((0,255,0))
#blank surfaces = pygame.Surface((x,y), pygame.SRCALPHA) 
#/NOTE

import pygame
from pygame.locals import *
import sys
import os
import button
import random
import math
pygame.init()
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720

os.chdir('roguelike experiment')
        
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Roguelike Experiment')


titlebackground = pygame.image.load('background/titlescreenBG.png')
titlebackground = pygame.transform.scale(titlebackground, (SCREEN_WIDTH, SCREEN_HEIGHT))



start = pygame.image.load("button/STARTbutton.png")
exit = pygame.image.load("button/EXITbutton.png")
options = pygame.image.load("button/OPTIONSbutton.png")
Continue = pygame.image.load("button/CONTINUEbutton.png")
menu = pygame.image.load("button/MENUbutton.png")
restart = pygame.image.load("button/RESTARTbutton.png")

save = pygame.image.load("button/SAVEbutton.png")

def game_over():
          
    global Menu, STRENGTH, SPEED, RANGED, DEFENSE, Gold, HasPlayed

    HasPlayed = False  
    
    gameover = str("You died.")
    rendergameover =deathfont.render(gameover, 1, pygame.Color("RED"))
    rect = rendergameover.get_rect(center=(SCREEN_WIDTH//2,SCREEN_HEIGHT//2))
    screen.fill((0,0,0))
    screen.blit(rendergameover, rect)
    #Menu button
    menu_button.active = True
    menu_clicked = menu_button.is_clicked()
    menu_button.move(400,420)
    menu_button.draw(screen)
    if menu_clicked:
        Menu = True
        menu_button.active = False
        HasPlayed = False
    #restart button
    restart_button.active = True
    restart_button.move(650,420)
    restart_clicked = restart_button.is_clicked()
    restart_button.draw(screen)
    if restart_clicked:
        Menu = False
        restart_button.active = False
        HasPlayed = True
        player.rect.topleft = (610, 600)
        player.change_direction("down")
        player.playerHP = 100
        STRENGTH = 0
        SPEED = 2
        RANGED = 0
        DEFENSE = 0
        Gold = 0
                

def fps_counter():
    fps = str(int(clock.get_fps()))
    fps_t = fpsfont.render(fps , 1, pygame.Color("YELLOW"))
    screen.blit(fps_t,(0,0))

def stat_counter():
    HPrender = str(player.playerHP)
    HP_t = statfont.render("HP: "+HPrender, 1, pygame.Color("WHITE"))
    screen.blit(HP_t, (0,680))
    STRrender = str(STRENGTH)
    STR_t = statfont.render("STR: "+STRrender, 1, pygame.Color("red"))
    screen.blit(STR_t, (0,480))
    DEFrender = str(DEFENSE)
    def_t = statfont.render("DEF: "+DEFrender, 1, pygame.Color("DODGERBLUE"))
    screen.blit(def_t, (0,580))
    RANGErender = str(RANGED)
    RANGE_t = statfont.render("RANGE: "+RANGErender, 1, pygame.Color("darkorange"))
    screen.blit(RANGE_t, (0,530))
    SPDrender = str(SPEED-2)
    SPD_t = statfont.render("SPEED: "+SPDrender, 1, pygame.Color("LIME"))
    screen.blit(SPD_t, (0, 630))
    MoneyRender = str(Gold)
    Money_t = statfont.render(MoneyRender+" Gold", 1, pygame.Color("GOLD"))
    MoneyTextWidth = Money_t.get_width()
    Money_x = SCREEN_WIDTH - 5 - MoneyTextWidth
    screen.blit(Money_t, (Money_x, 20))            

#load bad guys
DummyIMG = pygame.image.load('sprites/Enemy/Dummy.png')
#load you
PlayerSpritesheet = pygame.image.load('sprites/Player/spritesheet.png')
def get_image(spritesheet, width, height, x, y):
    image = pygame.Surface((width, height), pygame.SRCALPHA).convert_alpha()
    image.blit(spritesheet, (0,0), (x, y, width, height))
    return image
#load weapons
stickSPRITE = pygame.image.load("sprites/Weapon/stick.png")
Weaponless = pygame.image.load("sprites/Weapon/None.png")
SwordSPRITE = pygame.image.load("sprites/Weapon/Sword.png")



facingDown = get_image(PlayerSpritesheet, 13, 25, 0, 0)
facingUp = get_image(PlayerSpritesheet, 13, 25, 13, 0)
facingLeft = get_image(PlayerSpritesheet, 13, 25, 26, 0)
facingRight = get_image(PlayerSpritesheet, 13, 25, 0, 25)
#dashDown = get_image(PlayerSpritesheet, width, height, x, y)
#dashUp = get_image(PlayerSpritesheet, width, height, x, y)
#dashLeft = get_image(PlayerSpritesheet, width, height, x, y)
#dashRight = get_image(PlayerSpritesheet, width, height, x, y)

#fonts here
fpsfont = pygame.font.Font(None, size=30)
statfont = pygame.font.Font('font/Stepalange.otf', size=50)
deathfont = pygame.font.Font('font/Stepalange.otf', size=100)
titlefont =pygame.font.Font('font/Stepalange.otf', size=75)
creditfont = pygame.font.Font('font/StepalangeShort.otf', size=30)

#menus
Menu = True
PauseMenu = False
optionsMenu = False
#stop continue-bugging
HasPlayed = False

#need this for something
x=0
y=0

#borders
BorderLEFT = pygame.Rect(-7, 0, 1, SCREEN_HEIGHT)
BorderUP = pygame.Rect(0, -7, SCREEN_WIDTH, 1)
BorderDOWN = pygame.Rect(0, SCREEN_HEIGHT+7, SCREEN_WIDTH, 1)
BorderRIGHT = pygame.Rect(SCREEN_WIDTH+7, 0, 1, SCREEN_HEIGHT)

delta_time = 0.1
#setfps
FPS = 240
clock = pygame.time.Clock()
clock.tick(FPS)


#stats
STRENGTH = 0 # +1 strength = +1 melee damage
DEFENSE = 0 # +1 defense = +1% damage reduction
RANGED = 0 # +1 ranged + +1 ranged damage
SPEED = 2 # +1 speed = +1 pixel/second


#sprite layer groups
projectilesprite = pygame.sprite.Group()


#Enemy class
class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, sprite, scale, HP, EnemyDMG, is_attacking, attackCOOLDOWN, attackTIMER,):
        super().__init__()
        #def img
        self.sprite = sprite
        width= sprite.get_width()
        height = sprite.get_height()
        self.sprite = pygame.transform.scale(sprite, (int(width*scale), int(height*scale)))
        self.rect = self.sprite.get_rect()
        self.rect.topleft = (x,y)
        self.HP = math.inf
        self.EnemyDMG = 0
        self.is_attacking = False
        self.attackTIMER = 0
        self.attackCOOLDOWN = 0.5

    def draw(self):
        screen.blit(self.sprite, (self.rect.x, self.rect.y))
#enemy instances       
dummyENT = Enemy(610, 150, DummyIMG, 4, math.inf, 10, False, 0, 0)

#weapon class
class Weapon(pygame.sprite.Sprite):
    def __init__(self, sprite, scale, DAMAGE, weapon_type, cooldown, offset_x=0, offset_y=0):
        super().__init__()
        self.sprite = sprite
        self.scale = scale
        self.DAMAGE = DAMAGE
        self.weapon_type = weapon_type
        self.cooldown = cooldown
        self.lastAttack = 0

        width = sprite.get_width()
        height = sprite.get_height()
        self.sprite = pygame.transform.scale(sprite, (int(width * scale), int(height * scale)))
        self.rect = self.sprite.get_rect()
        self.offset_x = offset_x
        self.offset_y = offset_y
    def draw(self, surface, mountPOS, direction):
        x = mountPOS[0] + self.offset_x
        y = mountPOS[1] + self.offset_y
        self.rect.topleft = (x,y)
        if direction == "left":
            flipped_image = pygame.transform.flip(self.sprite, True, False)
            surface.blit(flipped_image, self.rect.topleft)
        elif direction == "down":
            flipped_image = pygame.transform.flip(self.sprite, True, False)
            surface.blit(flipped_image, self.rect.topleft)            
        else:
            surface.blit(self.sprite, self.rect.topleft)
            surface.blit(self.sprite, self.rect.topleft)

empty_weapon = Weapon(sprite=Weaponless, scale=1, DAMAGE=0, weapon_type=None, cooldown=0) # fallback for no weapon

#Player class
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, sprite, scale, playerHP, is_attacking, attackCOOLDOWN, attackTIMER, isDASHING, Weapon1, Weapon2, Weapon3):
        #sprite handling
        super().__init__()
        self.scale = scale

        self.direction = "down" 
        self.sprites = {
            "down": self.scale_image(sprite),
            
        }
        self.sprite = self.sprites["down"]
        self.rect = self.sprite.get_rect(topleft=(x, y))
        #attack
        self.is_attacking = False
        self.attackCOOLDOWN = 1
        self.attackTIMER = 0

        #HP
        self.playerHP = playerHP

        #dash
        self.isDASHING = False
        self.dashtimer = 0
        self.dashCD = 0
        self.dashDURATION = 0.08
        self.dashCD_DELAY = 0.75

        #endlag from dash
        self.dashENDLAG = False
        self.endlagTIMER = 0
        self.endlagDURATION = 0.02
        self.dashDIRECTION = None

        #weapons
        self.empty_weapon = empty_weapon
        self.Weapon1 = Weapon1 or self.empty_weapon
        self.Weapon2 = Weapon2 or self.empty_weapon
        self.Weapon3 = Weapon3 or self.empty_weapon
        self.activeWeapon = self.Weapon1
        #weapon mount
        self.weapon_mount_offsets = {
            "down":  (-20, 35),
            "up":    (40, 35),
            "left":  (-20, 35),
            "right": (40, 35)
        }
        
    def get_weapon_mount_pos(self):
        offset = self.weapon_mount_offsets[self.direction]
        return (self.rect.x + offset[0], self.rect.y + offset[1])

    def scale_image(self, image):
        width = image.get_width()
        height = image.get_height()
        return pygame.transform.scale(image, (int(width * self.scale), int(height * self.scale)))

    def add_direction_sprite(self, direction_name, image):
        self.sprites[direction_name] = self.scale_image(image)

    def change_direction(self, new_direction):
        if new_direction != self.direction:
            self.direction = new_direction
            self.sprite = self.sprites[new_direction]
            pos = self.rect.topleft
            self.rect = self.sprite.get_rect(topleft=pos)

    def Update(self, delta_time):
        #dash config
        if self.isDASHING:
            self.dashtimer -= delta_time
            if self.dashtimer <= 0:
                self.isDASHING = False

        #dash endlag config
        if self.dashENDLAG:
            self.endlagTIMER -= delta_time
            if self.endlagTIMER <= 0:
                self.dashENDLAG = False

        if self.dashCD > 0:
            self.dashCD -= delta_time


    def draw(self):
        screen.blit(self.sprite, self.rect.topleft)

    dash_MINENDLAG = 0.01


#weapon instances
stick = Weapon(stickSPRITE, scale=1, DAMAGE=10, weapon_type="Melee", cooldown=500)
sword = Weapon(SwordSPRITE, scale=1, DAMAGE=50, weapon_type="Melee", cooldown=500)

#player instance
player = Player((610), (600), facingDown, 4, 100, False, 0, 0, False, Weapon1=stick, Weapon2=None, Weapon3=None )

player.add_direction_sprite("up", facingUp)
player.add_direction_sprite("left", facingLeft)
player.add_direction_sprite("right", facingRight)

#unused atm will probably be deleted soon enough
GetAttacked = False
MeleeAttackedEnemy = False
RangeAttackedEnemy = False
KilledEnemy = False


Gold = 0
Weapon1 = "Stick"
Weapon2 = "None"
Weapon3 = "None"




def showtitlescreen():
    titlescreen1 = str("ROGUELIKE")
    rendertitlescreen = titlefont.render(titlescreen1, 1, pygame.Color("WHITE"))
    screen.blit(rendertitlescreen, (500, 30))
    titlescreen2 = str("e x p e r i m e n t")
    rendertitlescreen2 = titlefont.render(titlescreen2, 1, pygame.Color("WHITE"))
    screen.blit(rendertitlescreen2, (410, 100))
    credit = str("created by cyclxne!")
    rendercredit = creditfont.render(credit, 1, pygame.Color("WHITE"))
    creditPFP = pygame.image.load('cyclxne.png').convert_alpha()
    creditbutton = button.Button(760, 640, creditPFP, 0.1)
    creditbutton.draw(screen)
    screen.blit(rendercredit, (535, 650))

#resolutions for options
resolutions = ["1280x720", "1600x900", "1920x1080"]
resINDEX = 0
#defaut button positions
start_button = button.Button(540, 200, start, 0.5)
exit_button = button.Button(540, 500, exit, 0.5)
options_button = button.Button(540, 350, options, 0.5)
restart_button = button.Button(530, 420, restart, 0.5)
menu_button = button.Button(530, 430, menu, 0.5)
continue_button = button.Button(540, 200, Continue, 0.5)

start_button.active = False
exit_button.active = False
options_button.active = False
menu_button.active = False
restart_button.active = False
continue_button.active = False


save_button = button.Button(150,250, save, 0.5)
#loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                PauseMenu = not PauseMenu
                print("Pause menu = "+str(PauseMenu))
                # flush any held click so it doesn’t bleed through
                pygame.mouse.get_pressed()
    #need main menu here
    if Menu == True:
        

        start_clicked = start_button.is_clicked()
        exit_clicked = exit_button.is_clicked()
        options_clicked = options_button.is_clicked()
        menu_clicked = menu_button.is_clicked()
        continue_clicked = continue_button.is_clicked() if HasPlayed else False
        restart_clicked =  restart_button.is_clicked()

        start_button.move(540,200)
        exit_button.move(540,500)
        options_button.move(540, 350)

        player.playerHP = 100
        screen.blit(titlebackground, (0,0))

        start_button.active = True
        exit_button.active = True
        options_button.active = True
        menu_button.active = False
        continue_button.active = False

        start_button.draw(screen)
        exit_button.draw(screen)
        options_button.draw(screen)
        showtitlescreen()
    #button actions
        if start_clicked:
            HasPlayed = True
            Menu = False
            PauseMenu = False
            start_button.active = False
            exit_button.active = False
            options_button.active = False
            player.rect.topleft = (610, 600)
            player.change_direction("down")
            player.playerHP = 100
            STRENGTH = 0
            SPEED = 2
            RANGED = 0
            DEFENSE = 0
            Gold = 0
            
        if exit_clicked:
            running = False

        if options_clicked:
            Menu = False
            optionsMenu = True

            options_button.active = False
            start_button.active = False
            exit_button.active = False
            menu_button.active = True

    elif optionsMenu:
        #activate buttons
        continue_button.active = HasPlayed
        menu_button.active = True
        continue_clicked = continue_button.is_clicked() if HasPlayed else False
        menu_clicked = menu_button.is_clicked()

        #draw overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))  # RGBA with alpha
        screen.blit(titlebackground, (0, 0))
        screen.blit(overlay, (0, 0))
        menu_button.move(540,600)
        optionText = "OPTIONS"
        optionText_t = titlefont.render(optionText, 1, pygame.Color("WHITE"))
        optionText_rect = optionText_t.get_rect(center=(SCREEN_WIDTH // 2, 50))
        screen.blit(optionText_t, optionText_rect)
        optionText1 = "Nothing here yet..."
        optionText1_t = statfont.render(optionText1, 1, pygame.Color("WHITE"))
        optionText1_rect = optionText1_t.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT//2 - 100))
        screen.blit(optionText1_t, optionText1_rect) 

        #move buttons
        continue_button.move(540,450)

        #draw buttons!!
        continue_button.draw(screen)
        menu_button.draw(screen)

        if continue_clicked and HasPlayed:
            PauseMenu = False
            optionsMenu = False
            start_button.active = False
            exit_button.active = False
            options_button.active = False
            menu_button.active = False

        if menu_clicked:
            HasPlayed = False
            Menu = True
            optionsMenu = False
            start_button.active = True
            exit_button.active = True
            options_button.active = True
            menu_button.active = False

    elif PauseMenu:
            
            #move buttons
            menu_button.move(540, 260)
            options_button.move(540, 400)
            continue_button.move(540, 120)
            restart_button.move(540, 550)
            #draw overlay
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 180)) 
            screen.blit(titlebackground, (0, 0))
            screen.blit(overlay, (0, 0))

            #draw text
            pauseText = "PAUSED"
            pauseText_t = titlefont.render(pauseText, 1, pygame.Color("WHITE"))
            pauseText_rect = pauseText_t.get_rect(center=(SCREEN_WIDTH // 2, 50))
            screen.blit(pauseText_t, pauseText_rect)

            #draw buttons
            test_button = button.Button(100, 100, pygame.Surface((200, 100)), 1)
            test_button.image.fill((255, 0, 0))
            test_button.active = True
            
            #activate buttons
            menu_button.active = True
            options_button.active = True
            continue_button.active = True
            restart_button.active = True

            #clicked
            start_clicked = start_button.is_clicked()
            exit_clicked = exit_button.is_clicked()
            options_clicked = options_button.is_clicked()
            menu_clicked = menu_button.is_clicked()
            continue_clicked = continue_button.is_clicked() if HasPlayed else False
            restart_clicked =  restart_button.is_clicked()

            #DEBUG BUTTON
            test_clicked = test_button.is_clicked()
            if test_clicked:
                print("Clicked red debug button!")
            test_button.draw(screen)

            menu_button.draw(screen)
            options_button.draw(screen)
            continue_button.draw(screen)
            restart_button.draw(screen)

            if menu_clicked:
                print("menuing")
                HasPlayed = False
                Menu = True
                PauseMenu = False
                start_button.active = True
                exit_button.active = True
                options_button.active = True
                menu_button.active = False

            if options_clicked:
                print("optioning")
                PauseMenu = False
                optionsMenu = True
                options_button.active = False
                start_button.active = False
                exit_button.active = False
                menu_button.active = True

            if continue_clicked and HasPlayed:
                print("continuing")
                PauseMenu = False
                start_button.active = False
                exit_button.active = False
                options_button.active = False
                menu_button.active = False

            if restart_clicked:
                print("Restarting!")
                HasPlayed = False
                Menu = False
                PauseMenu = False
                player.playerHP = 100
                player.rect.topleft = (610, 600)
                player.change_direction("down")
                player.playerHP = 100
                STRENGTH = 0
                SPEED = 2
                RANGED = 0
                DEFENSE = 0
                Gold = 0
                options_button.active = False
                start_button.active = False
                exit_button.active = False
                menu_button.active = False

    else:
        #load all backlground right here
        background_path = "background/TUTORIAL_BG.png"

        background = pygame.image.load(background_path)
        background = pygame.transform.scale(background, (SCREEN_WIDTH, SCREEN_HEIGHT))
        screen.blit(background, (0, 0))
        
        
        #getting attacked
        if GetAttacked == True:
            player.playerHP -= Enemy.EnemyDMG * (DEFENSE/100)
            GetAttacked = False
        #attacking something
        if MeleeAttackedEnemy:
            Damage =  + STRENGTH
        if RangeAttackedEnemy:
            Damage =  + RANGED


           
        if background_path == "background/TUTORIAL_BG.png":
            dummyENT.draw()
        player.draw()
        player.activeWeapon.draw(screen, player.get_weapon_mount_pos(), player.direction)
        stat_counter() 
        fps_counter()
        if player.rect.colliderect(dummyENT):
            print("colliding") # until i fix movement and collisions

        #consistent movement across fps drops
        x += 50 * delta_time
        old_x = player.rect.x
        old_y = player.rect.y
        #cant move if dead, will use for death animation later on
        if player.playerHP > 0:
            movement = pygame.math.Vector2(0,0)
            key =pygame.key.get_pressed()
            if not player.isDASHING:            
                if key [pygame.K_w] or key [pygame.K_UP]:
                    player.rect.move_ip(0,-SPEED)
                    player.change_direction("up")
                if key [pygame.K_s] or key [pygame.K_DOWN]:            
                    player.rect.move_ip(0,SPEED)
                    player.change_direction("down")
                if key [pygame.K_a] or key [pygame.K_LEFT]:
                    player.rect.move_ip(-SPEED,0)
                    player.change_direction("left")
                if key [pygame.K_d] or key [pygame.K_RIGHT]:
                    player.rect.move_ip(SPEED,0)
                    player.change_direction("right")
                if key [pygame.K_1]:
                    player.activeWeapon = player.Weapon1
                if key [pygame.K_2]:
                    player.activeWeapon = player.Weapon2
                if key [pygame.K_3]:
                    player.activeWeapon = player.Weapon3
                            

            if movement.length_squared() > 0:
                movement = movement.normalize() * SPEED
                player.rect.move_ip(movement.x, movement.y)
                if abs(movement.x) > abs(movement.y):
                    if movement.x > 0:
                        player.change_direction("right")
                    else:
                        player.change_direction("left")
                else:
                    if movement.y > 0:
                        player.change_direction("down")
                    else:
                        player.change_direction("up")




            #tests remove when finished
            if key[pygame.K_y]:
                player.playerHP = 0
            if key[pygame.K_f]:
                STRENGTH += 1
            if key[pygame.K_g]:
                DEFENSE += 1
            if key[pygame.K_h]:
                RANGED += 1
            if key[pygame.K_j]:
                SPEED += 1
            if key[pygame.K_k]:
                Gold += 1
        else:       
            game_over()




        
    #border collisions
    if player.rect.colliderect(BorderLEFT):
        player.rect.x = old_x
    if player.rect.colliderect(BorderRIGHT):
        player.rect.x = old_x
    if player.rect.colliderect(BorderUP):
        player.rect.y = old_y
    if player.rect.colliderect(BorderDOWN):
        player.rect.y = old_y
    
        #dashes
        if event.type == pygame.KEYDOWN and not Menu and not PauseMenu and not optionsMenu:
            key = pygame.key.get_pressed()
            if event.key == pygame.K_LSHIFT:
                if not player.isDASHING and player.dashCD <=0:
                    w = key[pygame.K_w] or key[pygame.K_UP]
                    a = key[pygame.K_a] or key[pygame.K_LEFT]
                    d = key[pygame.K_d] or key[pygame.K_RIGHT]
                    s = key[pygame.K_s] or key[pygame.K_DOWN]
                    old_x, old_y = player.rect.x, player.rect.y
                    if not player.isDASHING and player.dashCD <= 0:
                        if w and a and not d:
                            direction = "left"
                        elif w and d and not a:
                            direction = "right"
                        elif w and not a and not d:
                            direction = "up"
                        elif s and a and not d:
                            direction = "left"
                        elif s and d and not a:
                            direction = "right"
                        elif s and not a and not d:
                            direction = "down"
                        elif a and not w and not d:
                            direction = "left"
                        elif d and not w and not a:
                            direction = "right"
                        else:
                            direction = "up"  #default direction

                        player.change_direction(direction)
                        if direction:
                            player.isDASHING = True
                            player.dashtimer = player.dashDURATION
                            player.dashCD = player.dashCD_DELAY
                            player.dashENDLAG = True
                            endlag = player.endlagDURATION + player.dashDURATION - SPEED/100
                            player.endlagTIMER = max(endlag,0.01)
                        if direction == "up":
                            dash_amount = min(SPEED*50, player.rect.top - BorderUP.bottom, 300)
                            player.rect.y -= dash_amount

                        elif direction == "down":
                            dash_amount = min(SPEED*50, BorderDOWN.top - player.rect.bottom, 300)
                            player.rect.y += dash_amount

                        elif direction == "left":
                            dash_amount = min(SPEED*50, player.rect.left - BorderLEFT.right, 300)
                            player.rect.x -= dash_amount

                        elif direction == "right":
                            dash_amount = min(SPEED*50, BorderRIGHT.left - player.rect.right, 300)
                            player.rect.x += dash_amount
                        
                            if player.rect.colliderect(BorderLEFT) or player.rect.colliderect(BorderRIGHT):
                                player.rect.x = old_x
                            if player.rect.colliderect(BorderUP) or player.rect.colliderect(BorderDOWN):
                                player.rect.y = old_y
                            player.change_direction(direction)

    player.Update(delta_time)
    if SPEED > 12:
        SPEED = 12
    if DEFENSE > 80:
        DEFENSE = 80
    pygame.display.flip()
    delta_time = clock.tick(FPS) / 1000
    delta_time = max(0.001, min(0.1, delta_time))

    
pygame.quit()
sys.exit()
